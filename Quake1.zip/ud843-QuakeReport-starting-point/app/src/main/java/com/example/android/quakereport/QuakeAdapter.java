package com.example.android.quakereport;
import android.content.Context;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class QuakeAdapter extends ArrayAdapter<Quake>
{
 //   private Context mContext;
  //  private List<Quake> quakeList= new ArrayList<Quake>();

    public QuakeAdapter(Context context,ArrayList<Quake> list )
    {
        super(context,0,list);
       // mContext=context;
       // quakeList=list;
    }


    @Override
    public View getView(int position, @Nullable View ConvertView, ViewGroup parent) {
       // return super.getView(position, ConvertView, parent);


        View listItem= ConvertView;
        if(listItem==null)
            listItem= LayoutInflater.from(getContext()).inflate(R.layout.quake_list,parent,false);

        Quake currentQuake=getItem(position);

        TextView magnitude=(TextView)listItem.findViewById(R.id.magnitude);
        magnitude.setText(currentQuake.getMagnitude());
        TextView location=(TextView)listItem.findViewById(R.id.location);
        location.setText(currentQuake.getLocation());

        TextView date=(TextView)listItem.findViewById(R.id.date);
        date.setText(currentQuake.getDate());
        return listItem;
    }
}

