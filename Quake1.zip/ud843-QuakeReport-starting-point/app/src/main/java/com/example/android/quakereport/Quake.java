package com.example.android.quakereport;

public class Quake {
    private double magnitude;
    private String location;
    private long date;
    private String mag_string;
    private String date_string;
    private String url;



    public Quake(double mag, String place, String time,String Url) {
        magnitude = mag;
        location = place;
        date_string = time;
        mag_string= Double.toString(magnitude);
        url=Url;

    }
    public String getUrl(){return url;}
    public String getMagnitude() {
        return mag_string;
    }

    public String getLocation() {
        return location;
    }

    public String getDate() { return date_string; }
}